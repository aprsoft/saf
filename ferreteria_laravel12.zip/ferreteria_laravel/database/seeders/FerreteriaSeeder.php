<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\{Category,Unit,ProductService,ProductUnit,PriceList,ProductPrice,Warehouse};

class FerreteriaSeeder extends Seeder {
    public function run(): void {
        DB::transaction(function () {
            $aridos = Category::updateOrCreate(['codigo'=>'ARIDOS'], ['nombre'=>'Áridos', 'parent_id'=>null]);
            $arenas = Category::updateOrCreate(['codigo'=>'ARENAS'], ['nombre'=>'Arenas','parent_id'=>$aridos->id]);
            $electricidad = Category::updateOrCreate(['codigo'=>'ELECTRICIDAD'], ['nombre'=>'Electricidad','parent_id'=>null]);
            $conductores = Category::updateOrCreate(['codigo'=>'CONDUCTORES'], ['nombre'=>'Conductores','parent_id'=>$electricidad->id]);
            $fijaciones = Category::updateOrCreate(['codigo'=>'FIJACIONES'], ['nombre'=>'Fijaciones','parent_id'=>null]);
            $servicios = Category::updateOrCreate(['codigo'=>'SERVICIOS'], ['nombre'=>'Servicios','parent_id'=>null]);
            $units = [];
            foreach ([['UN','Unidad',false],['KG','Kilogramo',true],['G','Gramo',true],['M','Metro',true],['L','Litro',true],['M3','Metro cúbico',true],['CAJA','Caja',false],['SACO','Saco',false],['ROLLO','Rollo',false],['H','Hora',true]] as [$symbol,$name,$decimal]) {
                $units[$symbol] = Unit::updateOrCreate(['simbolo'=>$symbol], ['nombre'=>$name,'permite_decimales'=>$decimal]);
            }
            $public = PriceList::updateOrCreate(['nombre'=>'Venta público'], ['tipo'=>'VENTA','incluye_iva'=>false]);
            $wholesale = PriceList::updateOrCreate(['nombre'=>'Venta mayorista'], ['tipo'=>'VENTA','incluye_iva'=>false]);
            PriceList::updateOrCreate(['nombre'=>'Compra proveedores'], ['tipo'=>'COMPRA','incluye_iva'=>false]);
            Warehouse::updateOrCreate(['codigo'=>'PRINCIPAL'], ['nombre'=>'Bodega principal']);
            $items = [
                ['ARENA-FINA','Arena fina','PRODUCTO',$arenas,'KG','KG','KG',true,[['KG',1,200],['SACO',25,4500]]],
                ['CABLE-THHN-25','Cable THHN 2,5 mm²','PRODUCTO',$conductores,'M','ROLLO','M',true,[['M',1,500],['ROLLO',100,44000]]],
                ['TORNILLO-2','Tornillo 2 pulgadas','PRODUCTO',$fijaciones,'UN','CAJA','UN',true,[['UN',1,100],['CAJA',100,8000]]],
                ['CORTE-CABLE','Servicio de corte de cable','SERVICIO',$servicios,'UN','UN','UN',false,[['UN',1,1000]]],
            ];
            foreach ($items as [$code,$name,$type,$category,$base,$purchase,$sale,$stock,$variants]) {
                $item = ProductService::updateOrCreate(['codigo'=>$code], [
                    'nombre'=>$name,'tipo'=>$type,'category_id'=>$category->id,
                    'stock_unit_id'=>$units[$base]->id,'purchase_unit_id'=>$units[$purchase]->id,
                    'sales_unit_id'=>$units[$sale]->id,'controla_stock'=>$stock,'afecto_iva'=>true,'activo'=>true
                ]);
                foreach ($variants as [$symbol,$factor,$price]) {
                    ProductUnit::updateOrCreate(['product_service_id'=>$item->id,'unit_id'=>$units[$symbol]->id], ['factor_conversion'=>$factor]);
                    ProductPrice::updateOrCreate(['product_service_id'=>$item->id,'unit_id'=>$units[$symbol]->id,'price_list_id'=>$public->id], ['precio'=>$price]);
                }
            }
        });
    }
}
