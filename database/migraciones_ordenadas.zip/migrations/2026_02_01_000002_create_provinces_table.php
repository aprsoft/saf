<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('provinces', function (Blueprint $table) {
            $table->id();
            $table->string('name');

            $table->foreignId('region_id')
                ->constrained('regions')
                ->cascadeOnDelete();

            $table->timestamps();

            $table->unique(['name', 'region_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('provinces');
    }
};
